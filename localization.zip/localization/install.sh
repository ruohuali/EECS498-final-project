pip3 install matplotlib
pip3 install numpy
pip3 install pybullet
pip3 install scipy